// Copyright 2020 Arthur Sonzogni. All rights reserved.
// Use of this source code is governed by the MIT license that can be found in
// the LICENSE file.
#include <ftxui/dom/direction.hpp>  // for Direction, Direction::Down, Direction::Left, Direction::Right, Direction::Up
#include <memory>                   // for allocator, make_shared
#include <string>                   // for string

#include "ftxui/dom/elements.hpp"  // for Element, gauge, gaugeDirection, gaugeDown, gaugeLeft, gaugeRight, gaugeUp
#include "ftxui/dom/node.hpp"         // for Node
#include "ftxui/dom/requirement.hpp"  // for Requirement
#include "ftxui/screen/box.hpp"       // for Box
#include "ftxui/screen/screen.hpp"    // for Screen, Cell

#include "ftxui/screen/terminal.hpp"  // for Quirks, GetQuirks

namespace ftxui {

namespace {
// NOLINTNEXTLINE
static const std::string charset_horizontal[11] = {
    " ", " ", "▏", "▎", "▍", "▌", "▋", "▊", "▉", "█",
    // An extra character in case when the fuzzer manage to have:
    // int(9 * (limit - limit_int) = 9
    "█"};

// NOLINTNEXTLINE
static const std::string charset_horizontal_microsoft[11] = {
    " ", " ", " ", " ", "▌", "▌", "▌", "█", "█", "█",
    // An extra character in case when the fuzzer manage to have:
    // int(9 * (limit - limit_int) = 9
    "█"};

// NOLINTNEXTLINE
static const std::string charset_vertical[10] = {
    "█",
    "▇",
    "▆",
    "▅",
    "▄",
    "▃",
    "▂",
    "▁",
    " ",
    // An extra character in case when the fuzzer manage to have:
    // int(8 * (limit - limit_int) = 8
    " ",
};

class Gauge : public Node {
 public:
  Gauge(float progress, Direction direction, std::vector<std::string> charset = {})
      : progress_(progress),
        direction_(direction),
        charset_(std::move(charset)) {
    // This handle NAN correctly:
    if (!(progress_ > 0.F)) {
      progress_ = 0.F;
    }
    if (!(progress_ < 1.F)) {
      progress_ = 1.F;
    }
  }

  void ComputeRequirement() override {
    switch (direction_) {
      case Direction::Right:
      case Direction::Left:
        requirement_.flex_grow_x = 1;
        requirement_.flex_grow_y = 0;
        requirement_.flex_shrink_x = 1;
        requirement_.flex_shrink_y = 0;
        break;
      case Direction::Up:
      case Direction::Down:
        requirement_.flex_grow_x = 0;
        requirement_.flex_grow_y = 1;
        requirement_.flex_shrink_x = 0;
        requirement_.flex_shrink_y = 1;
        break;
    }
    requirement_.min_x = 1;
    requirement_.min_y = 1;
  }

  void Render(Screen& screen) override {
    switch (direction_) {
      case Direction::Right:
        RenderHorizontal(screen, /*invert=*/false);
        break;
      case Direction::Up:
        RenderVertical(screen, /*invert=*/false);
        break;
      case Direction::Left:
        RenderHorizontal(screen, /*invert=*/true);
        break;
      case Direction::Down:
        RenderVertical(screen, /*invert=*/true);
        break;
    }
  }

  void RenderHorizontal(Screen& screen, bool invert) {
    if (box_.y_min > box_.y_max) {
      return;
    }

    // `full` is the index of the "full" glyph in `charset`; the boundary
    // cell picks glyph index int(full * fractional_fill).
    const std::string* charset;
    int full;
    if (charset_.empty()) {
      charset = Terminal::GetQuirks().BlockCharacters()  // NOLINT
                    ? charset_horizontal
                    : charset_horizontal_microsoft;
      full = 9;
    } else {
      charset = charset_.data();
      full = static_cast<int>(charset_.size()) - 1;
    }

    // Draw the progress bar horizontally across the full allocated height:
    const float progress = invert ? 1.F - progress_ : progress_;
    const auto limit =
        float(box_.x_min) + progress * float(box_.x_max - box_.x_min + 1);
    const int limit_int = static_cast<int>(limit);

    for (int y = box_.y_min; y <= box_.y_max; y++) {
      int x = box_.x_min;
      while (x < limit_int) {
        screen.at(x++, y) = charset[full];
      }
      if (x <= box_.x_max) {
        screen.at(x++, y) = charset[int(full * (limit - limit_int))];
      }
      while (x <= box_.x_max) {
        screen.at(x++, y) = charset[0];
      }
    }

    if (invert) {
      Invert(screen);
    }
  }

  void RenderVertical(Screen& screen, bool invert) {
    if (box_.x_min > box_.x_max) {
      return;
    }

    const std::string* charset;
    int full;
    if (charset_.empty()) {
      charset = charset_vertical;
      full = 8;
    } else {
      charset = charset_.data();
      full = static_cast<int>(charset_.size()) - 1;
    }

    // Draw the progress bar vertically across the full allocated width:
    const float progress = invert ? progress_ : 1.F - progress_;
    const float limit =
        float(box_.y_min) + progress * float(box_.y_max - box_.y_min + 1);
    const int limit_int = static_cast<int>(limit);

    for (int x = box_.x_min; x <= box_.x_max; x++) {
      int y = box_.y_min;
      while (y < limit_int) {
        screen.at(x, y++) = charset[full];
      }
      if (y <= box_.y_max) {
        screen.at(x, y++) = charset[int(full * (limit - limit_int))];
      }
      while (y <= box_.y_max) {
        screen.at(x, y++) = charset[0];
      }
    }
    if (invert) {
      Invert(screen);
    }
  }

  void Invert(Screen& screen) {
    for (int y = box_.y_min; y <= box_.y_max; y++) {
      for (int x = box_.x_min; x <= box_.x_max; x++) {
        screen.CellAt(x, y).inverted ^= true;
      }
    }
  }

 private:
  float progress_;
  Direction direction_;
  std::vector<std::string> charset_;
};

}  // namespace

/// @brief Draw a high definition progress bar progressing in specified
/// direction.
/// @param progress The proportion of the area to be filled. Belong to [0,1].
/// @param direction Direction of progress bars progression.
/// @ingroup dom
Element gaugeDirection(float progress, Direction direction) {
  return std::make_shared<Gauge>(progress, direction);
}

/// @brief Draw a high definition progress bar progressing from left to right.
/// @param progress The proportion of the area to be filled. Belong to [0,1].
/// @ingroup dom
///
/// ### Example
///
/// A gauge. It can be used to represent a progress bar.
/// ~~~cpp
/// border(gaugeRight(0.5))
/// ~~~
///
/// #### Output
///
/// ~~~bash
/// ┌──────────────────────────────────────────────────────────────────────────┐
/// │█████████████████████████████████████                                     │
/// └──────────────────────────────────────────────────────────────────────────┘
/// ~~~
Element gaugeRight(float progress) {
  return gaugeDirection(progress, Direction::Right);
}

/// @brief Draw a high definition progress bar progressing from right to left.
/// @param progress The proportion of the area to be filled. Belong to [0,1].
/// @ingroup dom
///
/// ### Example
///
/// A gauge. It can be used to represent a progress bar.
/// ~~~cpp
/// border(gaugeLeft(0.5))
/// ~~~
///
/// #### Output
///
/// ~~~bash
/// ┌──────────────────────────────────────────────────────────────────────────┐
/// │                                     █████████████████████████████████████│
/// └──────────────────────────────────────────────────────────────────────────┘
/// ~~~
Element gaugeLeft(float progress) {
  return gaugeDirection(progress, Direction::Left);
}

/// @brief Draw a high definition progress bar progressing from bottom to top.
/// @param progress The proportion of the area to be filled. Belong to [0,1].
/// @ingroup dom
///
/// ### Example
///
/// A gauge. It can be used to represent a progress bar.
/// ~~~cpp
/// border(gaugeUp(0.5))
/// ~~~
///
/// #### Output
///
/// ~~~bash
///  ┌─┐
///  │ │
///  │ │
///  │ │
///  │ │
///  │█│
///  │█│
///  │█│
///  │█│
///  └─┘
/// ~~~
Element gaugeUp(float progress) {
  return gaugeDirection(progress, Direction::Up);
}

/// @brief Draw a high definition progress bar progressing from top to bottom.
/// @param progress The proportion of the area to be filled. Belong to [0,1].
/// @ingroup dom
///
/// ### Example
///
/// A gauge. It can be used to represent a progress bar.
/// ~~~cpp
/// border(gaugeDown(0.5))
/// ~~~
///
/// #### Output
///
/// ~~~bash
///  ┌─┐
///  │█│
///  │█│
///  │█│
///  │█│
///  │ │
///  │ │
///  │ │
///  │ │
///  └─┘
/// ~~~
Element gaugeDown(float progress) {
  return gaugeDirection(progress, Direction::Down);
}

/// @brief Draw a high definition progress bar.
/// @param progress The proportion of the area to be filled. Belong to [0,1].
/// @ingroup dom
///
/// ### Example
///
/// A gauge. It can be used to represent a progress bar.
/// ~~~cpp
/// border(gauge(0.5))
/// ~~~
///
/// #### Output
///
/// ~~~bash
/// ┌──────────────────────────────────────────────────────────────────────────┐
/// │█████████████████████████████████████                                     │
/// └──────────────────────────────────────────────────────────────────────────┘
/// ~~~
Element gauge(float progress) {
  return gaugeRight(progress);
}

/// @brief Draw a high definition progress bar using a custom charset.
/// @param progress The proportion of the area to be filled. Belong to [0,1].
/// @param charset Glyphs from "empty" (index 0) to "full" (last index); a
/// 2-entry charset gives a plain unshaded bar.
/// @param direction Direction of progress bars progression. Defaults to
/// Right.
/// @ingroup dom
///
/// ### Example
///
/// A gauge rendered with a custom charset instead of the default block
/// characters.
/// ~~~cpp
/// border(gaugeCharset(0.5, {".", "#"}))
/// ~~~
///
/// #### Output
///
/// ~~~bash
/// ┌──────────────────────────────────────────────────────────────────────────┐
/// │#####################################.....................................│
/// └──────────────────────────────────────────────────────────────────────────┘
/// ~~~
Element gaugeCharset(float progress,
                      std::vector<std::string> charset,
                      Direction direction) {
  return std::make_shared<Gauge>(progress, direction, std::move(charset));
}

}  // namespace ftxui
